
%Demo done during Session 21 demonstrating
% DFT of finite length sinusoid
%L: length of sinusoid
%N: "length" of DFT = no. of equi-spaced
%   DTFT is evaluated (sampled) at
%   over 0 <= omega < 2pi
clf
set(0,'defaultaxesfontsize',16);
x1=exp(j*2*pi*(5/32)*(0:31));
y1=abs(fft(x1,32));
plot(0:length(y1)-1,y1,'Linewidth',3)
title('Case of N=L, x[n]=exp(j2\pi k/L)'),...
xlabel('k'), ylabel('Magnitude of DFT')
pause
z1=abs(fft(x1,128));
plot(0:length(z1)-1,z1,'Linewidth',3)
title('Case of N=4*L, x[n]=exp(j2\pi k/L)'),...
xlabel('k'), ylabel('Magnitude of DFT')
pause
x2=exp(j*2*pi*(5.5/32)*(0:31));
y2=abs(fft(x2,32));
plot(0:length(y2)-1,y2,'Linewidth',3)
title('Case of N=L, x[n]=exp[j2\pi (k+.5)/L]'),...
xlabel('k'), ylabel('Magnitude of DFT')
pause
z2=abs(fft(x2,128));
plot(0:length(z2)-1,z2,'Linewidth',3)
title('Case of N=4*L and w=2\pi (k+.5)/L'),...
xlabel('k'), ylabel('Magnitude of DFT')
%
pause
%
x1=cos(2*pi*(5/32)*(0:31));
y1=abs(fft(x1,32));
plot(0:length(y1)-1,y1,'Linewidth',3)
title('Case of N=L, x[n]=cos(2\pi kn/L)'),...
xlabel('k'), ylabel('Magnitude of DFT')
%
pause
z1=abs(fft(x1,128));
plot(0:length(z1)-1,z1,'Linewidth',3)
title('Case of N=4*L, x[n]=cos(2\pi kn/L)'),...
xlabel('k'), ylabel('Magnitude of DFT')
%
pause
x2=cos(2*pi*(5.5/32)*(0:31));
y2=abs(fft(x2,32));
plot(0:length(y2)-1,y2,'Linewidth',3)
title('Case of N=L, x[n]=cos[2\pi (k+.5)n/L]'),...
xlabel('k'), ylabel('Magnitude of DFT')
%
pause
z2=abs(fft(x2,128));
plot(0:length(z2)-1,z2,'Linewidth',3)
title('Case of N=4*L, x[n]=cos[2\pi (k+.5)n/L]'),...
xlabel('k'), ylabel('Magnitude of DFT')
%