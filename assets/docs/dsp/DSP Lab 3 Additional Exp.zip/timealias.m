
%time-domain aliasing due to not choosing
%"length" of DFT,N, equal to length of
%convolution M+L-1
%
clf
set(0,'defaultaxesfontsize',16);
%L=6; M=3;
%x=cos(pi/4*(0:(L-1))); h=[1 -sqrt(2) 1 ];
%L=4; M=4;
%x=ones(1,N); h=x;
L=4; M=3;
x=[1 2 2 1]; h=[1 2 3];
y=conv(x,h);
N=max([M L]);
xdft=fft(x,N);
hdft=fft(h,N);
ytilde=real(ifft(xdft.*hdft,N));
yalias=y(1:N)+[y(N+1:N+M-1) zeros(1,N-M+1) ];
Y=zeros(4,L+M-1);
Y(1,1:length(x))=x; 
Y(2,1:length(h))=h;
Y(3,1:length(ytilde))=ytilde;
Y(4,1:length(y))=y;
for ic=1:4,
subplot(2,2,ic), 
for n=1:length(Y(ic,:));
plot([n-1 n-1], [0 Y(ic,n)],'Linewidth',2),
axis([0 N min(min(Y')) max(max(Y'))]);
if n==1, hold on; end;
if ic==1, title('x(n)');
elseif ic==2, title('h(n)');
elseif ic==3, title('max[M,L] pt IDFT of H(k)X(k)'); xlabel('n');
elseif ic==4, title('y(n)=x(n)*h(n)'); xlabel('n');
axis([0 M+L-1 min(min(Y')) max(max(Y'))]);
end
plot([n-1 n-1], [0 Y(ic,n)],'o','Markersize',10,'Linewidth',4),
end
hold off
end
disp('see figure')
pause
Nnew=8;
xdft=fft(x,Nnew);
hdft=fft(h,Nnew);
y8ptdft=real(ifft(xdft.*hdft,Nnew));
clf
Y=zeros(4,Nnew);
Y(1,1:length(ytilde))=ytilde; 
Y(2,1:length(y))=y;
Y(3,1:length(yalias))=yalias;
Y(4,1:length(y8ptdft))=y8ptdft;
for ic=1:4,
subplot(2,2,ic), 
for n=1:length(Y(ic,:));
plot([n-1 n-1], [0 Y(ic,n)],'Linewidth',4),
axis([0 Nnew min(min(Y')) max(max(Y'))])
if n==1, hold on; end;
if ic==1, title('max{L,M} pt IDFT of H(k)X(k)');
elseif ic==2, title('y(n)=x(n)*h(n)');
elseif ic==3, title('ya(n)=y(n)+y(n+N)');
elseif ic==4, title('IDFT of 8 pt DFTs');
end
plot([n-1 n-1], [0 Y(ic,n)],'o','Markersize',10,'Linewidth',4),
end
hold off
end
disp('see figure')